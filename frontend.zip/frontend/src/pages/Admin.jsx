import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "sonner";
import { CalendarPlus, Check, Copy, Loader2, LogOut, X } from "lucide-react";
import { Logo } from "@/components/Logo";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;
const FULL_FMT = new Intl.DateTimeFormat("it-IT", { weekday: "short", day: "numeric", month: "short", year: "numeric" });

const STATUS = {
  in_attesa: { label: "In attesa", cls: "bg-clay/10 text-clay" },
  confermata: { label: "Confermata", cls: "bg-moss/10 text-moss" },
  cancellata: { label: "Cancellata", cls: "bg-stone/10 text-stone line-through" },
};

const api = axios.create({ baseURL: API, withCredentials: true });
api.interceptors.response.use(null, async (error) => {
  const cfg = error.config || {};
  if (error.response?.status === 401 && !cfg.__retried && !cfg.url.includes("/auth/refresh")) {
    cfg.__retried = true;
    try {
      await api.post("/auth/refresh", {}, { __skip: true });
      return api(cfg);
    } catch {
      return Promise.reject(error);
    }
  }
  return Promise.reject(error);
});

export default function Admin() {
  const [user, setUser] = useState(undefined); // undefined = checking
  const [bookings, setBookings] = useState(null);
  const [calendarUrl, setCalendarUrl] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const loadBookings = () => {
    api.get("/admin/bookings").then((r) => setBookings(r.data)).catch(() => setBookings([]));
    api.get("/admin/calendar-link").then((r) => setCalendarUrl(r.data.url)).catch(() => {});
  };

  useEffect(() => {
    api.get("/auth/me")
      .then((r) => { setUser(r.data); loadBookings(); })
      .catch(() => setUser(null));
  }, []);

  const login = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post("/auth/login", { email, password });
      setUser(data);
      loadBookings();
    } catch (err) {
      const d = err.response?.data?.detail;
      toast.error(typeof d === "string" ? d : "Accesso non riuscito");
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    await api.post("/auth/logout").catch(() => {});
    setUser(null);
    setBookings(null);
  };

  const setStatus = async (id, status) => {
    try {
      const { data } = await api.patch(`/admin/bookings/${id}`, { status });
      setBookings((bs) => bs.map((b) => (b.id === id ? data : b)));
      toast.success(status === "confermata" ? "Prenotazione confermata" : "Prenotazione cancellata");
    } catch {
      toast.error("Operazione non riuscita");
    }
  };

  if (user === undefined) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center text-stone text-sm gap-2" data-testid="admin-loading">
        <Loader2 className="w-4 h-4 animate-spin" /> Caricamento…
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center px-6" data-testid="admin-login-page">
        <form onSubmit={login} className="w-full max-w-sm border border-line bg-sand/40 p-10">
          <Logo />
          <h1 className="font-serif text-2xl text-ink mt-8">Area riservata</h1>
          <p className="text-sm text-stone mt-1 mb-8">Accedi per gestire le prenotazioni.</p>
          <label className="grid gap-2 text-sm text-stone mb-4">
            Email
            <input
              data-testid="admin-email-input"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border border-line bg-cream px-4 py-3 text-ink outline-none focus:border-clay transition-colors"
            />
          </label>
          <label className="grid gap-2 text-sm text-stone mb-8">
            Password
            <input
              data-testid="admin-password-input"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border border-line bg-cream px-4 py-3 text-ink outline-none focus:border-clay transition-colors"
            />
          </label>
          <button
            data-testid="admin-login-btn"
            disabled={loading}
            className="w-full bg-ink text-cream py-3 rounded-full text-sm hover:bg-clay transition-colors disabled:opacity-40 inline-flex items-center justify-center gap-2"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />} Accedi
          </button>
        </form>
      </div>
    );
  }

  const upcoming = (bookings || []).filter((b) => b.status !== "cancellata");
  const cancelled = (bookings || []).filter((b) => b.status === "cancellata");

  const Row = ({ b }) => (
    <tr className="border-b border-line text-sm" data-testid={`booking-row-${b.id}`}>
      <td className="py-4 pr-4 whitespace-nowrap capitalize">{FULL_FMT.format(new Date(`${b.date}T12:00:00`))}</td>
      <td className="py-4 pr-4 font-medium">{b.time}</td>
      <td className="py-4 pr-4">
        {b.service_name}
        {b.extras?.length > 0 && <span className="block text-xs text-stone">+ {b.extras.join(", ")}</span>}
        <span className="block text-xs text-clay">€{b.price}</span>
      </td>
      <td className="py-4 pr-4">
        {b.name}
        {b.location && <span className="block text-xs text-stone">Sede: {b.location}</span>}
      </td>
      <td className="py-4 pr-4 whitespace-nowrap">{b.phone}</td>
      <td className="py-4 pr-4">
        <span className={`text-xs px-2 py-1 ${STATUS[b.status]?.cls}`} data-testid={`booking-status-${b.id}`}>
          {STATUS[b.status]?.label}
        </span>
      </td>
      <td className="py-4">
        <div className="flex items-center gap-2 justify-end">
          {b.status !== "confermata" && b.status !== "cancellata" && (
            <button
              data-testid={`confirm-btn-${b.id}`}
              onClick={() => setStatus(b.id, "confermata")}
              title="Conferma"
              className="w-8 h-8 border border-line flex items-center justify-center text-moss hover:bg-moss hover:text-cream hover:border-moss transition-colors"
            >
              <Check className="w-4 h-4" />
            </button>
          )}
          {b.status !== "cancellata" && (
            <button
              data-testid={`cancel-btn-${b.id}`}
              onClick={() => setStatus(b.id, "cancellata")}
              title="Cancella"
              className="w-8 h-8 border border-line flex items-center justify-center text-clay hover:bg-clay hover:text-cream hover:border-clay transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <a
            data-testid={`ics-btn-${b.id}`}
            href={`${API}/bookings/${b.id}/ics`}
            title="Aggiungi a Calendario"
            className="w-8 h-8 border border-line flex items-center justify-center text-ink hover:bg-ink hover:text-cream transition-colors"
          >
            <CalendarPlus className="w-4 h-4" />
          </a>
        </div>
      </td>
    </tr>
  );

  const Table = ({ title, items, testid }) => (
    <section className="mb-14" data-testid={testid}>
      <h2 className="font-serif text-2xl text-ink mb-6">{title} <span className="text-stone text-lg">({items.length})</span></h2>
      {items.length === 0 ? (
        <p className="text-sm text-stone">Nessuna prenotazione.</p>
      ) : (
        <div className="overflow-x-auto border border-line bg-white px-6">
          <table className="w-full min-w-[760px]">
            <thead>
              <tr className="border-b border-line text-left text-[10px] uppercase tracking-widest text-stone">
                <th className="py-3 pr-4 font-medium">Data</th>
                <th className="py-3 pr-4 font-medium">Ora</th>
                <th className="py-3 pr-4 font-medium">Servizio</th>
                <th className="py-3 pr-4 font-medium">Cliente</th>
                <th className="py-3 pr-4 font-medium">Telefono</th>
                <th className="py-3 pr-4 font-medium">Stato</th>
                <th className="py-3 font-medium text-right">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map((b) => <Row key={b.id} b={b} />)}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );

  return (
    <div className="min-h-screen bg-cream" data-testid="admin-dashboard">
      <header className="border-b border-line bg-cream/85 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
          <Logo />
          <div className="flex items-center gap-6">
            <span className="text-sm text-stone hidden sm:block" data-testid="admin-user-email">{user.email}</span>
            <button
              data-testid="admin-logout-btn"
              onClick={logout}
              className="inline-flex items-center gap-2 text-sm text-stone hover:text-clay transition-colors"
            >
              <LogOut className="w-4 h-4" /> Esci
            </button>
          </div>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-6 md:px-12 py-14">
        <h1 className="font-serif text-4xl text-ink mb-2">Prenotazioni</h1>
        <p className="text-sm text-stone mb-8">
          Tocca l'icona calendario per aggiungere l'appuntamento al Calendario del tuo iPhone.
        </p>
        {calendarUrl && (
          <section className="border border-line bg-sand/40 p-6 mb-12 max-w-3xl" data-testid="calendar-sync-box">
            <h2 className="font-serif text-2xl text-ink mb-2">Sincronizza con l'iPhone di Anita</h2>
            <p className="text-sm text-stone mb-4 leading-relaxed">
              Sul suo iPhone: <strong>Impostazioni → App → Calendario → Account Calendario → Aggiungi account → Altro →
              Aggiungi calendario sottoscritto</strong>, poi incolla questo link e tocca <strong>Salva</strong>.
              Da quel momento ogni nuova prenotazione apparirà da sola nel suo Calendario.
            </p>
            <div className="flex items-stretch gap-2">
              <code className="flex-1 text-xs bg-cream border border-line px-3 py-3 break-all text-stone" data-testid="calendar-feed-url">
                {calendarUrl}
              </code>
              <button
                data-testid="copy-calendar-link-btn"
                onClick={() => {
                  navigator.clipboard?.writeText(calendarUrl);
                  toast.success("Link copiato: invialo ad Anita");
                }}
                className="inline-flex items-center gap-2 bg-ink text-cream px-5 text-sm hover:bg-clay transition-colors"
              >
                <Copy className="w-4 h-4" /> Copia link
              </button>
            </div>
          </section>
        )}
        {!bookings ? (
          <div className="flex items-center gap-2 text-stone text-sm"><Loader2 className="w-4 h-4 animate-spin" /> Caricamento…</div>
        ) : (
          <>
            <Table title="Prossimi appuntamenti" items={upcoming} testid="upcoming-table" />
            <Table title="Cancellate" items={cancelled} testid="cancelled-table" />
          </>
        )}
      </main>
    </div>
  );
}
