import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Marquee } from "@/components/Marquee";
import { Services } from "@/components/Services";
import { Gallery } from "@/components/Gallery";
import { BookingWizard } from "@/components/BookingWizard";
import { Footer } from "@/components/Footer";

const scrollToBooking = () => {
  const el = document.getElementById("prenota");
  if (!el) return;
  if (window.__lenis) window.__lenis.scrollTo(el, { offset: -60 });
  else el.scrollIntoView({ behavior: "smooth" });
};

export default function Home() {
  const [preselected, setPreselected] = useState(null);

  const selectService = (id) => {
    setPreselected(id);
    scrollToBooking();
  };

  return (
    <main className="bg-cream text-ink" data-testid="home-page">
      <Navbar />
      <Hero onBook={scrollToBooking} />
      <Marquee />
      <Services onSelect={selectService} />
      <Gallery />
      <BookingWizard preselectedService={preselected} />
      <Footer />
    </main>
  );
}
