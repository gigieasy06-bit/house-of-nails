import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "sonner";
import { Check, Copy, Loader2 } from "lucide-react";
import { Logo } from "@/components/Logo";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function Codice() {
  const [files, setFiles] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    axios.get(`${API}/source-code`).then((r) => setFiles(r.data.files)).catch(() => setFiles([]));
  }, []);

  const fullText = (files || [])
    .map((f) => `${"=".repeat(60)}\nFILE: ${f.path}\n${"=".repeat(60)}\n\n${f.content}`)
    .join("\n\n");

  const copyAll = async () => {
    try {
      await navigator.clipboard.writeText(fullText);
      setCopied(true);
      toast.success("Codice copiato negli appunti");
      setTimeout(() => setCopied(false), 2500);
    } catch {
      toast.error("Copia non riuscita: seleziona il testo manualmente");
    }
  };

  return (
    <div className="min-h-screen bg-cream" data-testid="codice-page">
      <header className="border-b border-line bg-cream/85 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-6 h-20 flex items-center justify-between">
          <a href="/" aria-label="Torna al sito"><Logo /></a>
          <button
            data-testid="copy-all-code-btn"
            onClick={copyAll}
            disabled={!files}
            className="inline-flex items-center gap-2 bg-ink text-cream px-6 py-3 rounded-full text-sm hover:bg-clay transition-colors disabled:opacity-40"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? "Copiato!" : "Copia tutto il codice"}
          </button>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-6 py-14">
        <h1 className="font-serif text-4xl text-ink mb-2">Codice completo del sito</h1>
        <p className="text-sm text-stone mb-10">
          Tutto il codice sorgente in un unico testo: premi il pulsante in alto per copiarlo e incollarlo dove vuoi.
        </p>
        {!files ? (
          <div className="flex items-center gap-2 text-stone text-sm"><Loader2 className="w-4 h-4 animate-spin" /> Caricamento…</div>
        ) : (
          <pre
            data-testid="source-code-content"
            className="text-xs leading-relaxed bg-ink text-cream/90 p-6 overflow-x-auto whitespace-pre-wrap break-words"
          >
            {fullText}
          </pre>
        )}
      </main>
    </div>
  );
}
