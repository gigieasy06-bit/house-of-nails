export const Logo = ({ dark = false }) => (
  <div className="flex items-center gap-3 select-none" data-testid="brand-logo">
    <img
      src="/logo.png"
      alt="House of Nails"
      className="w-12 h-12 rounded-full object-cover border border-line shadow-sm"
    />
    <div className="flex flex-col leading-none">
      <span className={`font-serif italic text-2xl ${dark ? "text-cream" : "text-ink"}`}>House of Nails</span>
      <span className={`text-[10px] tracking-[0.3em] uppercase mt-1 ${dark ? "text-cream/70" : "text-stone"}`}>
        di Anita
      </span>
    </div>
  </div>
);
