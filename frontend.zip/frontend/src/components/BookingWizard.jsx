import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import { toast } from "sonner";
import { CalendarPlus, Check, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const DAY_FMT = new Intl.DateTimeFormat("it-IT", { weekday: "short", day: "numeric", month: "short" });
const FULL_FMT = new Intl.DateTimeFormat("it-IT", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

const STEP_LABELS = ["Servizio", "Data", "Orario", "I tuoi dati", "Conferma"];

const isOpenDay = (d) => {
  const wd = d.getDay();
  if (wd === 1) return false; // lunedì chiuso
  if (wd === 0 && d.getDate() > 7) return false; // solo la prima domenica del mese
  return true;
};

const nextDays = (n) => {
  const days = [];
  const d = new Date();
  while (days.length < n) {
    if (isOpenDay(d)) days.push(new Date(d));
    d.setDate(d.getDate() + 1);
  }
  return days;
};

const toISO = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const formatDuration = (min) => {
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h}h ${m}min` : `${h} ${h > 1 ? "ore" : "ora"}`;
};

const LOCATIONS = ["Gottolengo", "Montichiari"];

export const BookingWizard = ({ preselectedService }) => {
  const [step, setStep] = useState(0);
  const [services, setServices] = useState([]);
  const [extrasList, setExtrasList] = useState([]);
  const [serviceId, setServiceId] = useState(preselectedService || null);
  const [date, setDate] = useState(null);
  const [slots, setSlots] = useState(null);
  const [time, setTime] = useState(null);
  const [extras, setExtras] = useState([]);
  const [location, setLocation] = useState(null);
  const [form, setForm] = useState({ name: "", phone: "", notes: "" });
  const [loading, setLoading] = useState(false);
  const [booking, setBooking] = useState(null);
  const days = useMemo(() => nextDays(14), []);

  useEffect(() => {
    axios.get(`${API}/services`).then((r) => setServices(r.data)).catch(() => {});
    axios.get(`${API}/extras`).then((r) => setExtrasList(r.data)).catch(() => {});
  }, []);

  useEffect(() => {
    if (preselectedService) setServiceId(preselectedService);
  }, [preselectedService]);

  useEffect(() => {
    if (!date || !serviceId) return;
    setSlots(null);
    setTime(null);
    axios
      .get(`${API}/availability`, { params: { date: toISO(date), service_id: serviceId } })
      .then((r) => setSlots(r.data.slots))
      .catch(() => toast.error("Impossibile caricare gli orari"));
  }, [date, serviceId]);

  const service = services.find((s) => s.id === serviceId);
  const extrasTotal = extrasList.filter((e) => extras.includes(e.id)).reduce((s, e) => s + e.price, 0);
  const total = (service?.price || 0) + extrasTotal;
  const showExtras = service && service.category !== "laminazione";

  const canNext =
    (step === 0 && serviceId) ||
    (step === 1 && date) ||
    (step === 2 && time) ||
    (step === 3 && form.name.trim().length >= 2 && form.phone.trim().length >= 6 && location);

  const submit = async () => {
    setLoading(true);
    try {
      const { data } = await axios.post(`${API}/bookings`, {
        service_id: serviceId,
        date: toISO(date),
        time,
        name: form.name.trim(),
        phone: form.phone.trim(),
        notes: form.notes.trim(),
        extras,
        location,
      });
      setBooking(data);
      setStep(4);
    } catch (e) {
      const d = e.response?.data?.detail;
      toast.error(typeof d === "string" ? d : "Qualcosa è andato storto. Riprova.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setStep(0);
    setServiceId(null);
    setDate(null);
    setTime(null);
    setExtras([]);
    setLocation(null);
    setForm({ name: "", phone: "", notes: "" });
    setBooking(null);
  };

  return (
    <section id="prenota" className="py-24 md:py-32" data-testid="booking-section">
      <div className="max-w-4xl mx-auto px-6 md:px-12">
        <div className="mb-14">
          <p className="text-xs tracking-[0.4em] uppercase text-clay mb-4">Prenotazioni</p>
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ink">Riserva il tuo momento.</h2>
        </div>

        <ol className="flex flex-wrap gap-x-8 gap-y-2 mb-12 text-xs uppercase tracking-[0.2em]">
          {STEP_LABELS.map((label, i) => (
            <li
              key={label}
              className={`flex items-center gap-2 pb-2 border-b-2 transition-colors ${
                i === step ? "border-clay text-ink" : i < step ? "border-moss text-moss" : "border-line text-stone/60"
              }`}
              data-testid={`step-indicator-${i}`}
            >
              <span className="font-serif italic text-sm">0{i + 1}</span> {label}
            </li>
          ))}
        </ol>

        <div className="border border-line bg-sand/40 p-6 md:p-12 min-h-[320px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.35 }}
            >
              {step === 0 && (
                <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3" data-testid="step-service">
                  {services.map((s) => (
                    <button
                      key={s.id}
                      data-testid={`wizard-service-${s.id}`}
                      onClick={() => setServiceId(s.id)}
                      className={`text-left border p-5 transition-all duration-300 ${
                        serviceId === s.id ? "border-clay bg-cream shadow-sm" : "border-line bg-cream/50 hover:border-stone"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-serif text-xl text-ink leading-snug">{s.name}</h3>
                        {serviceId === s.id && <Check className="w-5 h-5 text-clay shrink-0" />}
                      </div>
                      <p className="mt-2 text-sm text-clay font-medium">
                        €{s.price} · {formatDuration(s.duration_min)}
                      </p>
                    </button>
                  ))}
                </div>
              )}

              {step === 1 && (
                <div data-testid="step-date">
                  <p className="text-sm text-stone mb-6">
                    Aperti da martedì a sabato, 8:30–19:00. La prima domenica del mese apertura straordinaria 10:00–18:00.
                  </p>
                  <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 gap-2">
                    {days.map((d) => {
                      const active = date && toISO(d) === toISO(date);
                      const special = d.getDay() === 0;
                      return (
                        <button
                          key={toISO(d)}
                          data-testid={`wizard-date-${toISO(d)}`}
                          onClick={() => setDate(d)}
                          className={`relative border px-2 py-3 text-center transition-all duration-200 capitalize ${
                            active ? "border-clay bg-clay text-cream" : "border-line bg-cream hover:border-stone"
                          }`}
                        >
                          <span className="block text-[10px] uppercase tracking-widest opacity-70">
                            {DAY_FMT.format(d).split(" ")[0]}
                          </span>
                          <span className="block font-serif text-xl">{d.getDate()}</span>
                          <span className="block text-[10px] uppercase tracking-widest opacity-70">
                            {DAY_FMT.format(d).split(" ")[2]}
                          </span>
                          {special && (
                            <span className={`block text-[9px] mt-1 ${active ? "text-cream/90" : "text-clay"}`}>
                              straordinaria
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {step === 2 && (
                <div data-testid="step-time">
                  <p className="text-sm text-stone mb-6 capitalize">
                    {date && FULL_FMT.format(date)} — {service?.name}, {service && formatDuration(service.duration_min)}.
                  </p>
                  {!slots ? (
                    <div className="flex items-center gap-2 text-stone text-sm">
                      <Loader2 className="w-4 h-4 animate-spin" /> Caricamento orari…
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {slots.map((s) => (
                        <button
                          key={s.time}
                          data-testid={`wizard-slot-${s.time}`}
                          disabled={!s.available}
                          onClick={() => setTime(s.time)}
                          className={`border px-5 py-3 text-sm transition-all duration-200 ${
                            !s.available
                              ? "border-line text-stone/40 line-through cursor-not-allowed bg-cream/40"
                              : time === s.time
                                ? "border-clay bg-clay text-cream"
                                : "border-line bg-cream hover:border-stone"
                          }`}
                        >
                          {s.time}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {step === 3 && (
                <div className="grid gap-5 max-w-md" data-testid="step-details">
                  <fieldset data-testid="location-picker">
                    <legend className="text-sm text-stone mb-3">Scegli la sede</legend>
                    <div className="grid grid-cols-2 gap-2">
                      {LOCATIONS.map((loc) => (
                        <button
                          key={loc}
                          type="button"
                          data-testid={`wizard-location-${loc.toLowerCase()}`}
                          onClick={() => setLocation(loc)}
                          className={`border px-4 py-3 text-sm transition-all duration-200 ${
                            location === loc ? "border-clay bg-clay text-cream" : "border-line bg-cream hover:border-stone"
                          }`}
                        >
                          {loc}
                        </button>
                      ))}
                    </div>
                  </fieldset>
                  {showExtras && (
                    <fieldset data-testid="extras-picker">
                      <legend className="text-sm text-stone mb-3">Extra <span className="text-stone/60">(facoltativo)</span></legend>
                      <div className="flex flex-wrap gap-2">
                        {extrasList.map((e) => {
                          const on = extras.includes(e.id);
                          return (
                            <button
                              key={e.id}
                              type="button"
                              data-testid={`wizard-extra-${e.id}`}
                              onClick={() => setExtras(on ? extras.filter((x) => x !== e.id) : [...extras, e.id])}
                              className={`border px-4 py-2 text-sm transition-all duration-200 ${
                                on ? "border-clay bg-clay text-cream" : "border-line bg-cream hover:border-stone"
                              }`}
                            >
                              {e.name} +€{e.price}
                            </button>
                          );
                        })}
                      </div>
                    </fieldset>
                  )}
                  <label className="grid gap-2 text-sm text-stone">
                    Nome e cognome
                    <input
                      data-testid="wizard-input-name"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Maria Rossi"
                      className="border border-line bg-cream px-4 py-3 text-ink outline-none focus:border-clay transition-colors"
                    />
                  </label>
                  <label className="grid gap-2 text-sm text-stone">
                    Telefono
                    <input
                      data-testid="wizard-input-phone"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder="333 123 4567"
                      type="tel"
                      className="border border-line bg-cream px-4 py-3 text-ink outline-none focus:border-clay transition-colors"
                    />
                  </label>
                  <label className="grid gap-2 text-sm text-stone">
                    Note <span className="text-stone/60">(facoltativo)</span>
                    <textarea
                      data-testid="wizard-input-notes"
                      value={form.notes}
                      onChange={(e) => setForm({ ...form, notes: e.target.value })}
                      rows={3}
                      placeholder="Allergie, preferenze di colore…"
                      className="border border-line bg-cream px-4 py-3 text-ink outline-none focus:border-clay transition-colors resize-none"
                    />
                  </label>
                  {service && (
                    <p className="text-sm text-ink border border-line bg-cream px-4 py-3" data-testid="wizard-total">
                      Totale in sede: <span className="text-clay font-medium">€{total}</span>
                      <span className="text-stone"> · {service.name}{extrasTotal > 0 ? ` + extra €${extrasTotal}` : ""}</span>
                    </p>
                  )}
                </div>
              )}

              {step === 4 && booking && (
                <div data-testid="step-confirmation">
                  <div className="flex items-center gap-3 mb-8">
                    <span className="w-10 h-10 rounded-full bg-moss/15 flex items-center justify-center">
                      <Check className="w-5 h-5 text-moss" />
                    </span>
                    <h3 className="font-serif text-3xl text-ink">Prenotazione ricevuta!</h3>
                  </div>
                  <dl className="grid sm:grid-cols-2 gap-x-10 gap-y-4 text-sm max-w-lg">
                    <div><dt className="text-stone uppercase tracking-widest text-[10px]">Servizio</dt><dd className="text-ink text-base mt-1">{booking.service_name}</dd></div>
                    <div><dt className="text-stone uppercase tracking-widest text-[10px]">Quando</dt><dd className="text-ink text-base mt-1 capitalize">{FULL_FMT.format(new Date(`${booking.date}T12:00:00`))} · {booking.time}</dd></div>
                    <div><dt className="text-stone uppercase tracking-widest text-[10px]">Nome</dt><dd className="text-ink text-base mt-1">{booking.name}</dd></div>
                    <div><dt className="text-stone uppercase tracking-widest text-[10px]">Telefono</dt><dd className="text-ink text-base mt-1">{booking.phone}</dd></div>
                    {booking.location && (
                      <div><dt className="text-stone uppercase tracking-widest text-[10px]">Sede</dt><dd className="text-ink text-base mt-1">{booking.location}</dd></div>
                    )}
                    {booking.extras?.length > 0 && (
                      <div><dt className="text-stone uppercase tracking-widest text-[10px]">Extra</dt><dd className="text-ink text-base mt-1">{booking.extras.join(", ")}</dd></div>
                    )}
                  </dl>
                  <p className="mt-8 inline-block border border-clay/40 bg-clay/5 text-clay text-sm px-4 py-2" data-testid="payment-note">
                    Pagamento in sede · €{booking.price}
                  </p>
                  <div className="mt-8 flex flex-wrap gap-4">
                    <a
                      data-testid="add-to-calendar-btn"
                      href={`${API}/bookings/${booking.id}/ics`}
                      className="inline-flex items-center gap-2 bg-ink text-cream px-6 py-3 rounded-full text-sm hover:bg-clay transition-colors"
                    >
                      <CalendarPlus className="w-4 h-4" /> Aggiungi a Calendario
                    </a>
                    <button
                      data-testid="new-booking-btn"
                      onClick={reset}
                      className="text-sm text-stone border-b border-stone pb-1 hover:text-clay hover:border-clay transition-colors"
                    >
                      Nuova prenotazione
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {step < 4 && (
          <div className="mt-8 flex items-center justify-between">
            <button
              data-testid="wizard-back-btn"
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0}
              className="inline-flex items-center gap-2 text-sm text-stone hover:text-ink transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4" /> Indietro
            </button>
            {step < 3 ? (
              <button
                data-testid="wizard-next-btn"
                onClick={() => canNext && setStep((s) => s + 1)}
                disabled={!canNext}
                className="inline-flex items-center gap-2 bg-ink text-cream px-7 py-3 rounded-full text-sm hover:bg-clay transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
              >
                Avanti <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                data-testid="wizard-submit-btn"
                onClick={submit}
                disabled={!canNext || loading}
                className="inline-flex items-center gap-2 bg-clay text-cream px-7 py-3 rounded-full text-sm hover:bg-ink transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />} Conferma prenotazione · €{total}
              </button>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
