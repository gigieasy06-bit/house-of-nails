import { Logo } from "./Logo";

export const Footer = () => (
  <footer id="orari" className="bg-ink text-cream py-20" data-testid="footer">
    <div className="max-w-7xl mx-auto px-6 md:px-12 grid md:grid-cols-3 gap-12">
      <div>
        <Logo dark />
        <p className="mt-6 text-cream/60 text-sm max-w-xs leading-relaxed">
          Unghie, pedicure e laminazione ciglia curati nel dettaglio. Ti aspettiamo in sede.
        </p>
      </div>
      <div>
        <h3 className="text-xs tracking-[0.35em] uppercase text-cream/50 mb-5">Orari</h3>
        <ul className="text-sm space-y-2 text-cream/80">
          <li className="flex justify-between gap-6 max-w-[280px]"><span>Martedì – Sabato</span><span>8:30 – 19:00</span></li>
          <li className="flex justify-between gap-6 max-w-[280px]"><span>Domenica (1ª del mese)</span><span>10:00 – 18:00</span></li>
          <li className="flex justify-between gap-6 max-w-[280px] text-cream/40"><span>Lunedì</span><span>Chiuso</span></li>
        </ul>
      </div>
      <div>
        <h3 className="text-xs tracking-[0.35em] uppercase text-cream/50 mb-5">Info</h3>
        <ul className="text-sm space-y-2 text-cream/80">
          <li>Pagamento in sede</li>
          <li>Prenotazione online gratuita</li>
          <li>Extra: French, Babyboomer, decorazioni +€5</li>
        </ul>
      </div>
    </div>
    <div className="max-w-7xl mx-auto px-6 md:px-12 mt-16 pt-8 border-t border-cream/10 flex flex-wrap gap-4 justify-between text-xs text-cream/40">
      <span>© {new Date().getFullYear()} House of Nails · di Anita</span>
      <span className="flex gap-6">
        <a href="/codice" className="hover:text-cream transition-colors" data-testid="footer-codice-link">Codice sorgente</a>
        <a href="/admin" className="hover:text-cream transition-colors" data-testid="footer-admin-link">Area riservata</a>
      </span>
    </div>
  </footer>
);
