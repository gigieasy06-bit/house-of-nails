import { motion } from "framer-motion";

const GROUPS = [
  {
    id: "unghie",
    title: "Unghie",
    sub: "Nail Care",
    items: [
      { id: "manicure", name: "Manicure", note: "Cura completa delle mani", duration: "1 ora", price: 25 },
      { id: "semipermanente", name: "Semipermanente rinforzato", note: "Unghie corte/medie", duration: "1 ora", price: 35 },
      { id: "copertura_gel", name: "Copertura unghie gel", note: "Sull'unghia naturale", duration: "1 ora e 20", price: 45 },
      { id: "allungamento", name: "Allungamento", note: "In gel, forma a scelta", duration: "2 ore", price: 60 },
      { id: "spa_mani", name: "Spa mani", note: "Trattamento rigenerante", duration: "15 min", price: 10 },
      { id: "rimozione_manicure", name: "Rimozione + manicure curativa", note: "Rimozione delicata del prodotto", duration: "45 min", price: 20 },
    ],
    extras: "Extra: French +€5 · Babyboomer +€5 · Piccole decorazioni +€5",
  },
  {
    id: "pedicure",
    title: "Pedicure",
    sub: "Foot Care",
    items: [
      { id: "pedicure_curativa", name: "Pedicure curativa + smalto semipermanente", note: "Cura completa dei piedi", duration: "1 ora e 15", price: 45 },
      { id: "semipermanente_piedi", name: "Solo semipermanente", note: "Smalto semipermanente piedi", duration: "45 min", price: 30 },
    ],
  },
  {
    id: "laminazione",
    title: "Laminazione Coreana",
    sub: "Lash & Brow",
    items: [
      { id: "laminazione_ciglia", name: "Laminazione coreana ciglia", note: "Esalta le tue ciglia naturali con una curvatura personalizzata", duration: "1 ora", price: 60 },
      { id: "laminazione_sopracciglia", name: "Laminazione coreana sopracciglia", note: "Sopracciglia ordinate e piene", duration: "45 min", price: 40 },
      { id: "combo_laminazione", name: "Combo laminazione coreana ciglia + sopracciglia", note: "Trattamento completo", duration: "1 ora", price: 80 },
    ],
  },
];

export const Services = ({ onSelect }) => (
  <section id="servizi" className="py-24 md:py-32" data-testid="services-section">
    <div className="max-w-7xl mx-auto px-6 md:px-12 grid md:grid-cols-12 gap-12">
      <div className="md:col-span-4">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="md:sticky md:top-28"
        >
          <p className="text-xs tracking-[0.4em] uppercase text-clay mb-4">Listino prezzi</p>
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ink mb-10">Ogni gesto, il suo prezzo.</h2>
          <div className="border border-line bg-sand p-3 hidden md:block">
            <img src="/nuovo2.jpeg" alt="Copertura gel rosa realizzata da Anita" className="w-full aspect-[3/4] object-cover" />
          </div>
          <p className="mt-6 font-serif italic text-xl text-clay">pagamento in sede, sempre</p>
        </motion.div>
      </div>
      <div className="md:col-span-8">
        {GROUPS.map((g, gi) => (
          <motion.div
            key={g.id}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, delay: gi * 0.08 }}
            className="mb-14"
            data-testid={`listino-${g.id}`}
          >
            <div className="flex items-baseline gap-4 border-b border-ink pb-3 mb-2">
              <h3 className="font-serif text-3xl text-ink">{g.title}</h3>
              <span className="font-serif italic text-lg text-clay">{g.sub}</span>
            </div>
            <ul>
              {g.items.map((s) => (
                <li key={s.id} className="group flex items-center gap-4 py-4 border-b border-line" data-testid={`listino-item-${s.id}`}>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between gap-4">
                      <span className="text-ink text-base md:text-lg">{s.name}</span>
                      <span className="hidden sm:block flex-1 border-b border-dotted border-stone/40 -translate-y-1" />
                      <span className="text-clay font-medium whitespace-nowrap">€ {s.price}</span>
                    </div>
                    <p className="text-sm text-stone mt-1">{s.note} · {s.duration}</p>
                  </div>
                  <button
                    data-testid={`listino-book-${s.id}`}
                    onClick={() => onSelect(s.id)}
                    className="text-xs uppercase tracking-[0.15em] text-stone border-b border-transparent group-hover:text-clay group-hover:border-clay hover:!text-clay hover:!border-clay transition-colors whitespace-nowrap"
                  >
                    Prenota →
                  </button>
                </li>
              ))}
            </ul>
            {g.extras && (
              <p className="mt-4 inline-block border border-clay/40 bg-clay/5 text-clay text-sm px-4 py-2" data-testid="extras-note">
                {g.extras}
              </p>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);
