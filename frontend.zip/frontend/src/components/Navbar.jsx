import { Logo } from "./Logo";

const scrollTo = (id) => {
  const el = document.getElementById(id);
  if (!el) return;
  if (window.__lenis) window.__lenis.scrollTo(el, { offset: -80 });
  else el.scrollIntoView({ behavior: "smooth" });
};

export const Navbar = () => (
  <header className="fixed top-0 inset-x-0 z-50 bg-cream/85 backdrop-blur-md border-b border-line">
    <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
      <a href="#top" onClick={(e) => { e.preventDefault(); scrollTo("top"); }} aria-label="House of Nails">
        <Logo />
      </a>
      <nav className="hidden md:flex items-center gap-10 text-sm tracking-wide text-stone">
        <button data-testid="nav-servizi" onClick={() => scrollTo("servizi")} className="hover:text-clay transition-colors">Servizi</button>
        <button data-testid="nav-galleria" onClick={() => scrollTo("galleria")} className="hover:text-clay transition-colors">Galleria</button>
        <button data-testid="nav-orari" onClick={() => scrollTo("orari")} className="hover:text-clay transition-colors">Orari</button>
      </nav>
      <button
        data-testid="nav-prenota-btn"
        onClick={() => scrollTo("prenota")}
        className="bg-ink text-cream text-sm px-6 py-3 rounded-full hover:bg-clay transition-colors duration-300"
      >
        Prenota ora
      </button>
    </div>
  </header>
);
