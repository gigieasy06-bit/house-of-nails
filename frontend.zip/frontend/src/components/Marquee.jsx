const items = ["House of Nails", "Semipermanente", "Copertura Gel", "Allungamento", "Pedicure", "Laminazione Coreana", "Pagamento in sede"];

export const Marquee = () => {
  const row = [...items, ...items, ...items];
  return (
    <div className="bg-sand border-y border-line py-5 overflow-hidden" data-testid="marquee-strip">
      <div className="marquee-track flex whitespace-nowrap w-max">
        {[0, 1].map((half) => (
          <div key={half} className="flex">
            {row.map((t, i) => (
              <span key={`${half}-${i}`} className="font-serif text-2xl md:text-3xl text-ink flex items-center">
                <span className={i % 2 ? "italic text-clay" : ""}>{t}</span>
                <span className="mx-8 text-clay text-lg">•</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
