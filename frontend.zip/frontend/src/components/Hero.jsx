import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

const HERO_IMG =
  "https://images.unsplash.com/photo-1610992015762-45dca7fa3a85?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzV8MHwxfHNlYXJjaHwyfHxjbGVhbiUyMG1pbmltYWwlMjBtYW5pY3VyZSUyMG5haWxzfGVufDB8fHx8MTc5MjI0Mjg3N3ww&ixlib=rb-4.1.0&q=85";

const lines = ["Le tue mani,", "la nostra arte."];

export const Hero = ({ onBook }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], [0, 120]);

  return (
    <section ref={ref} id="top" className="relative min-h-screen flex items-center pt-28 pb-16 overflow-hidden" data-testid="hero-section">
      <div className="max-w-7xl mx-auto px-6 md:px-12 grid md:grid-cols-12 gap-12 items-center w-full">
        <div className="md:col-span-7 relative z-10">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.7 }}
            className="text-xs tracking-[0.4em] uppercase text-clay mb-8"
          >
            House of Nails · di Anita
          </motion.p>
          <h1 className="font-serif text-ink text-5xl sm:text-6xl lg:text-8xl leading-[1.02]">
            {lines.map((line, i) => (
              <span key={line} className="block overflow-hidden pb-1">
                <motion.span
                  className={`block ${i === 1 ? "italic text-clay" : ""}`}
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ delay: 0.35 + i * 0.18, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                >
                  {line}
                </motion.span>
              </span>
            ))}
          </h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.7 }}
            className="mt-8 max-w-md text-stone text-base md:text-lg leading-relaxed"
          >
            Manicure, gel, pedicure e laminazione ciglia curati nel dettaglio.
            Prenota online in pochi tocchi e paga comodamente in sede.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.05, duration: 0.7 }}
            className="mt-10 flex items-center gap-6"
          >
            <button
              data-testid="hero-prenota-btn"
              onClick={onBook}
              className="bg-clay text-cream px-8 py-4 rounded-full text-sm tracking-wide hover:bg-ink transition-colors duration-300"
            >
              Prenota il tuo appuntamento
            </button>
            <span className="text-xs uppercase tracking-[0.25em] text-stone">Mar–Sab · 8:30–19:00</span>
          </motion.div>
        </div>
        <div className="md:col-span-5 relative">
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="border border-line bg-sand p-4 md:translate-y-8"
          >
            <motion.div style={{ y: imgY }} className="overflow-hidden">
              <img
                src={HERO_IMG}
                alt="Manicure rosa su superficie bianca"
                className="w-full aspect-[3/4] object-cover scale-110"
                data-testid="hero-image"
              />
            </motion.div>
          </motion.div>
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="hidden md:block absolute -bottom-6 -left-6 font-serif italic text-2xl text-clay"
          >
            dal cuore, alle mani
          </motion.span>
        </div>
      </div>
    </section>
  );
};
