import { motion } from "framer-motion";

const IMAGES = [
  {
    src: "/lavoro3.jpeg",
    alt: "Nail art con fiore bianco realizzata da Anita",
    cls: "aspect-[4/5]",
  },
  {
    src: "/nuovo2.jpeg",
    alt: "Copertura gel rosa babyboomer",
    cls: "aspect-[3/4]",
  },
  {
    src: "/lavoro1.jpeg",
    alt: "French manicure su fondo nero",
    cls: "aspect-[4/5]",
  },
  {
    src: "/nuovo3.jpeg",
    alt: "French manicure fresca di giornata",
    cls: "aspect-[3/4]",
  },
  {
    src: "/lavoro2.jpeg",
    alt: "French manicure con stellina",
    cls: "aspect-[4/5]",
  },
  {
    src: "https://images.unsplash.com/photo-1754799670312-8e7da8e40ad7?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2MjJ8MHwxfHNlYXJjaHwzfHxsdXh1cnklMjBuYWlsJTIwYXJ0JTIwbWFuaWN1cmV8ZW58MHx8fHwxNzkyMjQyODc3fDA&ixlib=rb-4.1.0&q=85",
    alt: "Nail art blu e oro",
    cls: "aspect-square",
  },
  {
    src: "https://images.pexels.com/photos/11124957/pexels-photo-11124957.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Unghie rosa su superficie bianca",
    cls: "aspect-square",
  },
];

export const Gallery = () => (
  <section id="galleria" className="py-24 md:py-32 bg-sand border-y border-line" data-testid="gallery-section">
    <div className="max-w-7xl mx-auto px-6 md:px-12">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.7 }}
        className="mb-16 flex items-end justify-between gap-8"
      >
        <div>
          <p className="text-xs tracking-[0.4em] uppercase text-clay mb-4">Galleria</p>
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ink">Ispirazioni per le tue unghie.</h2>
        </div>
        <span className="hidden md:block font-serif italic text-xl text-stone">ogni mano racconta una storia</span>
      </motion.div>
      <div className="columns-2 md:columns-3 gap-6 [&>figure]:mb-6">
        {IMAGES.map((img, i) => (
          <motion.figure
            key={img.src}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.6, delay: (i % 3) * 0.1 }}
            className="break-inside-avoid border border-line bg-cream p-2 group"
            data-testid={`gallery-item-${i}`}
          >
            <div className="overflow-hidden">
              <img
                src={img.src}
                alt={img.alt}
                loading="lazy"
                className={`w-full object-cover ${img.cls} transition-transform duration-700 group-hover:scale-105`}
              />
            </div>
          </motion.figure>
        ))}
      </div>
      <motion.figure
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.7 }}
        className="mt-10 border border-line bg-cream p-2 group"
        data-testid="gallery-item-prima-dopo"
      >
        <div className="overflow-hidden">
          <img
            src="/nuovo4.jpeg"
            alt="Laminazione coreana ciglia: prima e dopo, realizzata da Anita"
            loading="lazy"
            className="w-full object-contain bg-sand transition-transform duration-700 group-hover:scale-[1.02]"
          />
        </div>
        <figcaption className="flex items-baseline justify-between px-2 py-3">
          <span className="font-serif italic text-xl text-ink">Laminazione coreana</span>
          <span className="text-xs uppercase tracking-[0.25em] text-clay">prima / dopo</span>
        </figcaption>
      </motion.figure>
    </div>
  </section>
);
